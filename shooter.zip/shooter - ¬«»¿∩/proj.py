from pygame import *
import math
w = 1200
h = 920
from random import *
init()
loseScore = 0
RocketFallS = 0
PlaneFallS = 0
window = display.set_mode((w,h))
display.set_caption("лабіринт")
background = transform.scale(image.load("BG.png"), (w,h))
rocket_image = "Rocket.png"
enemyPlane = "EnemyPlane.png"
hero_image = "plane.png"
enemyRo = "EnemyRo.png"
boom = "BOOM.png"
enemyTank = "EnemyTank.png"
text = "txt.png"
score = 0
class Player(sprite.Sprite):
    def __init__(self, x, y, player_image, speed, width, height ):
        super().__init__()
        self.image = transform.scale(image.load(player_image),(width,height))
        self.speed = speed
        self.rect = self.image.get_rect() #створити рамку навколо спрайта
        self.rect.x = x
        self.rect.y = y
    def reset(self):
        window.blit(self.image, (self.rect.x, self.rect.y))
numd = 1
angleRo =0
anglePlane =0   
f1 = font.SysFont('arial.ttf', 25)
f2 = font.SysFont('arial.ttf', 50)
#text1 = f1.render(score, 1, (180, 0, 0))
backupRoc = ""
backupPlane = ""
#text2 = f1.render("Кнопка 3 - противо-танкова ракета, кнопка 4 - універсальна", 100, (0, 20, 0))



mixer.init()
explosion = mixer.Sound("Explosion.ogg")
missle = mixer.Sound("missle.ogg")
fail = mixer.Sound("fail.ogg")
mixer.music.load("BGmusic.ogg")

mixer.music.play()
class Rocket(Player):
    def update(self ):
        keys = key.get_pressed()
        self.rect.x -= self.speed
        global numd
        if keys[K_1] and self.rect.x < 0:
            self.rect.x = 1000
            self.rect.y = hero.rect.y
            missle.play()
class Rocket2(Player):
    def update(self):
        keys = key.get_pressed()
        self.rect.x -= self.speed
        global numd
        if keys[K_2] and self.rect.x < 0:
            self.rect.x = 1000
            self.rect.y = hero.rect.y 
            missle.play()

class Rocket3(Player):
    def update(self):
        keys = key.get_pressed()
        self.rect.x -= self.speed
        global numd
        if keys[K_3] and self.rect.x < 0 :
            self.rect.x = 1000
            self.rect.y = hero.rect.y
            missle.play()
class bomb(Player):
    def update(self ):
        keys = key.get_pressed()
        self.rect.y += self.speed

        if keys[K_SPACE] and self.rect.y> 1700:
            self.rect.x = hero.rect.x
            self.rect.y = hero.rect.y + 100 
            missle.play()
class Heart1(Player):
    def update(self):
        global loseScore
        if loseScore == 1:
            self.rect.x = 40000
class Heart2(Player):
    def update(self):
        global loseScore
        if loseScore == 2:
            self.rect.x = 40000
class Heart3(Player):
    def update(self):
        global loseScore
        if loseScore == 3:
            self.rect.x = 40000
class Boom(Player):
    def update(self ):
        self.rect.y += self.speed
        self.rect.x += self.speed/2
class Text(Player):
    def update(self ):
        self.rect.y += self.speed
class Text(Player):
    def update(self ):
        print(hero.rect.y)
        if hero.rect.y > 100:
            self.rect.x = 10000
class Hero(Player):
    def update(self):
        keys = key.get_pressed()
        if keys[K_UP] and self.rect.y>-100:
            self.rect.y -= self.speed
        if keys[K_DOWN] and self.rect.y<h-100 :
            self.rect.y +=self.speed
            
class EnemyRock(Player):
    def update(self):
        if self.rect.x == 900:
            global RocketFallS
            global angleRo
            global backupRoc
            backupRoc = self.image
            RocketFallS= self.speed*(round((920-self.rect.y)/300))
            angleRo = math.degrees(math.asin(300/(math.sqrt(math.pow(self.rect.y, 2)+math.pow(300, 2)))))
            self.image = transform.rotate(self.image, int(360 - angleRo))
        self.rect.x +=self.speed
        self.rect.y += RocketFallS
        global enemyRo
        if self.rect.x == 1200:
            self.image = backupRoc
            angleRo = 0
            RocketFallS = 0
            global loseScore
            loseScore += 1
            return loseScore
        if self.rect.x > 1200 or self.rect.x == -1000 :
            self.rect.y = randint(0, 300)
            self.rect.x = 0
class EnemyPlane(Player):
    def update(self):
        global backupPlane
        backupPlane = self.image
        if self.rect.x == 903:
            global PlaneFallS
            global anglePlane
            PlaneFallS= self.speed*(round((920-self.rect.y)/300))
            angleRo = math.degrees(math.asin(300/(math.sqrt(math.pow(self.rect.y, 2)+math.pow(300, 2)))))
            self.image = transform.rotate(self.image, int(360 - angleRo))
        self.rect.x +=self.speed
        self.rect.y += PlaneFallS
        if self.rect.x == 1197:
            self.image = backupPlane
            anglePlane = 0
            PlaneFallS = 0
            global loseScore
            loseScore += 1
            return loseScore
            
        if self.rect.x > 1200 or self.rect.x == -1000:
            self.image = backupPlane
            anglePlane = 0
            PlaneFallS = 0
            self.image = backupPlane
            self.rect.y = randint(300, 820)

            self.rect.x = 0
class EnemyTank(Player):
    def update(self):
        self.rect.x +=self.speed
        if self.rect.x == 1000:
            global loseScore
            loseScore += 1
            return loseScore
        if self.rect.x > 1200 or self.rect.x == -1000:
            self.rect.y = 670
            self.rect.x = -300
            

text = Text(300, 300, text, 0, 400, 400)
heart1 = Heart1(100, 0, hero_image, 0 , 100 , 100)
heart2 = Heart2(200, 0, hero_image, 0 , 100 , 100)
heart3 = Heart3(300, 0, hero_image, 0 , 100 , 100)
hero = Hero(900, 0, hero_image, 20 , 200 , 200)
rocket1 = Rocket(-1000,-100,rocket_image, 50, 150, 150)
rocket2 = Rocket2(-1000,-100,rocket_image, 50, 150, 150)
rocket3 = Rocket3(-1000,-100,rocket_image, 50, 150, 150)
rocket4 = bomb(-1000,-100,rocket_image, 50, 150, 150)
enemyRocket = EnemyRock(-3000,790,enemyRo, 10, 150, 150)
enemyTank = EnemyTank(-5000,790,enemyTank,5, 300, 300)
enemyPlane = EnemyPlane(-1000,790,enemyPlane, 7, 150, 150)
boomPlane = Boom(7000,790,boom, 30, 150, 150)
boomTank = Boom(7000,790,boom, 30,150, 150)
boomRocket = Boom(7000,790,boom, 30, 150, 150)
clock = time.Clock()
FPS = 40
game = True
finish = False

while game:
    for e in event.get():
        if e.type == QUIT :
            game = False
            
    if finish != True:
        if sprite.collide_rect(rocket1, enemyPlane) or sprite.collide_rect(rocket4, enemyPlane) :
            boomPlane.rect.x = enemyPlane.rect.x
            boomPlane.rect.y = enemyPlane.rect.y
            enemyPlane.rect.x = 1200
            rocket1.rect.y = -200
            rocket4.rect.y = 2000
            score += 1
            explosion.play()
        if sprite.collide_rect(rocket2, enemyRocket) or sprite.collide_rect(rocket4, enemyRocket) :
            boomRocket.rect.x = enemyRocket.rect.x
            boomRocket.rect.y = enemyRocket.rect.y
            enemyRocket.rect.x = -1300
            rocket2.rect.y = -200
            rocket4.rect.y = 2000 
            score += 1
            explosion.play()
        if sprite.collide_rect(rocket3, enemyTank) or sprite.collide_rect(rocket4, enemyTank)  :
            boomTank.rect.x = enemyTank.rect.x
            boomTank.rect.y = enemyTank.rect.y
            rocket3.rect.y = -200
            rocket4.rect.y = 2000 
            enemyTank.rect.x = -1300
            score += 1
            explosion.play()
        if loseScore == 3:
            mixer.music.stop()
            fail.play()
            finish = True
        window.blit(background,(0,0))

        Ftext = "Нажаль, ви програли. Ваш рахунок - "+ str(score)
        failt = f2.render(Ftext , 100, (0, 20, 0))
        text1 = f1.render("Ваш рахунок - "+str(score) +" Ваші життя - "+ str(10 - loseScore), 100, (0, 20, 0))
        window.blit(text1, (700, 0))
        hero.update()
        hero.reset()
        rocket1.update()
        rocket1.reset()
        rocket2.update()
        rocket2.reset()
        rocket3.update()
        rocket3.reset()
        rocket4.update()
        rocket4.reset()
        enemyRocket.update()
        enemyRocket.reset()
        enemyTank.update()
        enemyTank.reset()
        enemyPlane.update()
        enemyPlane.reset()
        boomTank.reset()
        boomTank.update()
        boomPlane.reset()
        boomPlane.update()
        boomRocket.reset()
        boomRocket.update()
        heart1.reset()
        heart1.update()
        heart2.reset()
        heart2.update()
        heart3.reset()
        heart3.update()
        text.update()
        text.reset()


    display.update()
    clock.tick(FPS)
    window.blit(failt, (130, 500))